import Link from "next/link"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Server, LogOut, Plus, Activity, Clock, Cpu, HardDrive, Zap } from "lucide-react"
import DashboardNav from "@/components/dashboard-nav"

export const metadata: Metadata = {
  title: "Dashboard | SonexMC",
  description: "Manage your Minecraft servers on SonexMC",
}

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/" className="flex items-center gap-2">
            <Server className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SonexMC</span>
          </Link>
          <nav className="ml-auto flex items-center gap-4">
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
            <Button variant="outline" size="icon">
              <LogOut className="h-4 w-4" />
              <span className="sr-only">Logout</span>
            </Button>
          </nav>
        </div>
      </header>
      <div className="flex flex-1">
        <DashboardNav />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Server
            </Button>
          </div>
          <div className="grid gap-6">
            <Tabs defaultValue="servers">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="servers">My Servers</TabsTrigger>
                <TabsTrigger value="stats">Statistics</TabsTrigger>
                <TabsTrigger value="billing">Billing</TabsTrigger>
              </TabsList>
              <TabsContent value="servers" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Survival World</CardTitle>
                        <Badge className="bg-green-500 text-white">Online</Badge>
                      </div>
                      <CardDescription>survival.sonexmc.com</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center gap-2">
                          <Cpu className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">2 vCores</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <HardDrive className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">4GB RAM</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">12 Players</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">99.9% Uptime</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <Button variant="outline" className="w-full">
                        Manage
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Creative Build</CardTitle>
                        <Badge className="bg-green-500 text-white">Online</Badge>
                      </div>
                      <CardDescription>creative.sonexmc.com</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center gap-2">
                          <Cpu className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">2 vCores</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <HardDrive className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">4GB RAM</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">5 Players</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">99.9% Uptime</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <Button variant="outline" className="w-full">
                        Manage
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card className="border-dashed">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Add New Server</CardTitle>
                      <CardDescription>Deploy a new Minecraft server</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col items-center justify-center py-6">
                      <div className="rounded-full bg-muted p-3">
                        <Plus className="h-6 w-6 text-muted-foreground" />
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <Button className="w-full">Create Server</Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="stats">
                <Card>
                  <CardHeader>
                    <CardTitle>Server Statistics</CardTitle>
                    <CardDescription>View performance metrics for your servers</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] flex items-center justify-center border rounded-md">
                      <Activity className="h-16 w-16 text-muted-foreground/40" />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="billing">
                <Card>
                  <CardHeader>
                    <CardTitle>Billing Information</CardTitle>
                    <CardDescription>Manage your subscription and payment methods</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-lg border p-4">
                        <div className="font-medium">Current Plan: Standard</div>
                        <div className="text-sm text-muted-foreground">$12.99/month • Renews on April 15, 2025</div>
                        <div className="mt-4 flex gap-2">
                          <Button variant="outline" size="sm">
                            Change Plan
                          </Button>
                          <Button variant="outline" size="sm">
                            Billing History
                          </Button>
                        </div>
                      </div>
                      <div className="rounded-lg border p-4">
                        <div className="font-medium">Payment Method</div>
                        <div className="text-sm text-muted-foreground">Visa ending in 4242</div>
                        <div className="mt-4">
                          <Button variant="outline" size="sm">
                            Update Payment Method
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}

