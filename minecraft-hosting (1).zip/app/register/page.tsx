import type { Metadata } from "next"
import RegisterClientPage from "./RegisterClientPage"

export const metadata: Metadata = {
  title: "Register | SonexMC",
  description: "Create a new SonexMC account to start hosting your Minecraft server",
}

export default function RegisterPage() {
  return <RegisterClientPage />
}

