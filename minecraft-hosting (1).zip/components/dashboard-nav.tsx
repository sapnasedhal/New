"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Server, Settings, Users, CreditCard, HelpCircle, BarChart, Shield, FileText } from "lucide-react"

export default function DashboardNav() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <Server className="h-5 w-5" />,
    },
    {
      title: "My Servers",
      href: "/dashboard/servers",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Backups",
      href: "/dashboard/backups",
      icon: <Shield className="h-5 w-5" />,
    },
    {
      title: "Console",
      href: "/dashboard/console",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: "Players",
      href: "/dashboard/players",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Billing",
      href: "/dashboard/billing",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      title: "Support",
      href: "/dashboard/support",
      icon: <HelpCircle className="h-5 w-5" />,
    },
  ]

  return (
    <div className="hidden border-r bg-muted/40 md:block md:w-64 lg:w-72">
      <div className="flex h-full flex-col gap-2 p-4">
        <div className="py-2">
          <h2 className="px-4 text-lg font-semibold tracking-tight">Client Area</h2>
        </div>
        <div className="flex-1">
          <nav className="grid gap-1 px-2">
            {navItems.map((item, index) => (
              <Button
                key={index}
                asChild
                variant={pathname === item.href ? "secondary" : "ghost"}
                className={cn("justify-start", pathname === item.href ? "bg-muted" : "")}
              >
                <Link href={item.href}>
                  {item.icon}
                  <span className="ml-2">{item.title}</span>
                </Link>
              </Button>
            ))}
          </nav>
        </div>
        <div className="mt-auto">
          <div className="rounded-lg bg-muted p-4">
            <h3 className="font-medium">Need help?</h3>
            <p className="mt-1 text-sm text-muted-foreground">Our support team is available 24/7 to assist you.</p>
            <Button className="mt-3 w-full" size="sm">
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

