"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FAQAccordion() {
  const faqs = [
    {
      question: "What Minecraft versions do you support?",
      answer:
        "We support all Minecraft versions from 1.7.10 to the latest release, including Bedrock Edition. Our platform automatically updates to support new versions as they are released.",
    },
    {
      question: "How do I install mods or plugins on my server?",
      answer:
        "Our control panel provides one-click installations for popular modpacks and plugins. You can also upload custom mods through our file manager or FTP access. We support Forge, Fabric, Spigot, Paper, and more.",
    },
    {
      question: "Can I upgrade my plan later if I need more resources?",
      answer:
        "You can upgrade your plan at any time with just a few clicks from your control panel. Your server data will be automatically transferred to the new plan with minimal downtime.",
    },
    {
      question: "Do you offer a money-back guarantee?",
      answer:
        "Yes, we offer a 7-day money-back guarantee on all plans. If you're not satisfied with our service for any reason, you can request a full refund within the first 7 days of your subscription.",
    },
    {
      question: "How do I backup my server?",
      answer:
        "All plans include automated daily backups that are stored for 7 days. You can also create manual backups at any time through the control panel, and download them for local storage.",
    },
    {
      question: "Can I use a custom domain for my server?",
      answer:
        "Yes, Standard and Premium plans include the ability to use a custom domain for your server. We provide easy-to-follow instructions for setting up DNS records to point to your server.",
    },
    {
      question: "What kind of support do you offer?",
      answer:
        "We offer 24/7 support via ticket system for all customers. Premium plan subscribers also get priority support with faster response times and access to our Discord support channel.",
    },
    {
      question: "Can I transfer my existing Minecraft world to your hosting?",
      answer:
        "Yes, you can easily upload your existing world files through our control panel or FTP. We also offer a free migration service if you're moving from another hosting provider.",
    },
  ]

  return (
    <div className="mx-auto max-w-3xl py-8">
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
            <AccordionContent>{faq.answer}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  )
}

