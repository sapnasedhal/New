import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap, Shield, Clock, Server, Wrench, Download, BarChart, Layers, Repeat } from "lucide-react"

export default function FeatureGrid() {
  const features = [
    {
      icon: Zap,
      title: "High Performance",
      description: "Powered by NVMe SSDs and high-frequency CPUs for lag-free gameplay.",
    },
    {
      icon: Shield,
      title: "DDoS Protection",
      description: "Enterprise-grade protection against DDoS attacks to keep your server online.",
    },
    {
      icon: Clock,
      title: "Instant Setup",
      description: "Get your server up and running in less than 60 seconds.",
    },
    {
      icon: Server,
      title: "Global Network",
      description: "Servers in multiple locations worldwide for low-latency connections.",
    },
    {
      icon: Wrench,
      title: "Easy Management",
      description: "User-friendly control panel to manage your server with just a few clicks.",
    },
    {
      icon: Download,
      title: "One-Click Installs",
      description: "Install popular modpacks, plugins, and game versions with a single click.",
    },
    {
      icon: BarChart,
      title: "Resource Monitoring",
      description: "Real-time monitoring of your server's performance and resource usage.",
    },
    {
      icon: Layers,
      title: "Multiple Game Versions",
      description: "Support for all Minecraft versions from legacy to the latest releases.",
    },
    {
      icon: Repeat,
      title: "Automated Backups",
      description: "Regular automated backups to protect your world and configurations.",
    },
  ]

  return (
    <div className="grid gap-6 pt-8 md:grid-cols-2 lg:grid-cols-3">
      {features.map((feature, index) => (
        <Card key={index} className="border bg-background/60 backdrop-blur supports-[backdrop-filter]:bg-background/30">
          <CardHeader className="pb-2">
            <feature.icon className="h-6 w-6 text-primary mb-2" />
            <CardTitle className="text-xl">{feature.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription className="text-sm text-muted-foreground">{feature.description}</CardDescription>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

