"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2 } from "lucide-react"

type PlanFeature = {
  name: string
  included: boolean
}

type Plan = {
  id: string
  name: string
  description: string
  priceMonthly: number
  priceYearly: number
  ram: string
  cpu: string
  storage: string
  players: string
  popular?: boolean
  features: PlanFeature[]
}

export default function PricingPlans() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")

  const plans: Plan[] = [
    {
      id: "starter",
      name: "Starter",
      description: "Perfect for small friend groups and new servers.",
      priceMonthly: 5.99,
      priceYearly: 59.99,
      ram: "2GB",
      cpu: "1 vCore",
      storage: "15GB SSD",
      players: "10",
      features: [
        { name: "Instant Setup", included: true },
        { name: "DDoS Protection", included: true },
        { name: "Automated Backups", included: true },
        { name: "Modpack Support", included: true },
        { name: "Custom Domain", included: false },
        { name: "Priority Support", included: false },
      ],
    },
    {
      id: "standard",
      name: "Standard",
      description: "Great for medium-sized communities with mods.",
      priceMonthly: 12.99,
      priceYearly: 129.99,
      ram: "4GB",
      cpu: "2 vCores",
      storage: "30GB SSD",
      players: "25",
      popular: true,
      features: [
        { name: "Instant Setup", included: true },
        { name: "DDoS Protection", included: true },
        { name: "Automated Backups", included: true },
        { name: "Modpack Support", included: true },
        { name: "Custom Domain", included: true },
        { name: "Priority Support", included: false },
      ],
    },
    {
      id: "premium",
      name: "Premium",
      description: "For large communities with heavy modpacks.",
      priceMonthly: 24.99,
      priceYearly: 249.99,
      ram: "8GB",
      cpu: "4 vCores",
      storage: "50GB SSD",
      players: "50+",
      features: [
        { name: "Instant Setup", included: true },
        { name: "DDoS Protection", included: true },
        { name: "Automated Backups", included: true },
        { name: "Modpack Support", included: true },
        { name: "Custom Domain", included: true },
        { name: "Priority Support", included: true },
      ],
    },
  ]

  return (
    <div className="space-y-8 py-8">
      <div className="flex justify-center">
        <div className="flex items-center space-x-2">
          <Label
            htmlFor="billing-toggle"
            className={billingCycle === "monthly" ? "font-medium" : "text-muted-foreground"}
          >
            Monthly
          </Label>
          <Switch
            id="billing-toggle"
            checked={billingCycle === "yearly"}
            onCheckedChange={(checked) => setBillingCycle(checked ? "yearly" : "monthly")}
          />
          <div className="flex items-center gap-1.5">
            <Label
              htmlFor="billing-toggle"
              className={billingCycle === "yearly" ? "font-medium" : "text-muted-foreground"}
            >
              Yearly
            </Label>
            <Badge variant="outline" className="bg-primary/10 text-primary hover:bg-primary/20">
              Save 17%
            </Badge>
          </div>
        </div>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <Card key={plan.id} className={`flex flex-col ${plan.popular ? "border-primary shadow-md" : ""}`}>
            {plan.popular && (
              <div className="absolute right-4 top-4">
                <Badge className="bg-primary text-primary-foreground">Popular</Badge>
              </div>
            )}
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="mb-4">
                <span className="text-3xl font-bold">
                  ${billingCycle === "monthly" ? plan.priceMonthly : plan.priceYearly}
                </span>
                <span className="text-muted-foreground">{billingCycle === "monthly" ? "/month" : "/year"}</span>
              </div>
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-2 rounded-lg border p-3">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">RAM</p>
                    <p className="text-sm font-medium">{plan.ram}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">CPU</p>
                    <p className="text-sm font-medium">{plan.cpu}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Storage</p>
                    <p className="text-sm font-medium">{plan.storage}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Players</p>
                    <p className="text-sm font-medium">{plan.players}</p>
                  </div>
                </div>
                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle2
                        className={`h-4 w-4 ${feature.included ? "text-primary" : "text-muted-foreground/40"}`}
                      />
                      <span className={`text-sm ${feature.included ? "" : "text-muted-foreground/60 line-through"}`}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full" variant={plan.popular ? "default" : "outline"}>
                <Link href={`/register?plan=${plan.id}&billing=${billingCycle}`}>Choose {plan.name}</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      <div className="text-center text-sm text-muted-foreground">
        All plans include a 7-day money-back guarantee and 24/7 customer support.
      </div>
    </div>
  )
}

