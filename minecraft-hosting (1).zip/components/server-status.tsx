"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react"

type ServerRegion = {
  id: string
  name: string
  status: "online" | "offline" | "issues"
  latency: number
}

export default function ServerStatus() {
  const [regions, setRegions] = useState<ServerRegion[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching server status data
    const timer = setTimeout(() => {
      setRegions([
        { id: "us-east", name: "US East", status: "online", latency: 12 },
        { id: "us-west", name: "US West", status: "online", latency: 24 },
        { id: "eu-central", name: "EU Central", status: "online", latency: 18 },
        { id: "asia-east", name: "Asia East", status: "issues", latency: 45 },
        { id: "australia", name: "Australia", status: "online", latency: 36 },
      ])
      setLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "offline":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "issues":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      default:
        return null
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "online":
        return "Online"
      case "offline":
        return "Offline"
      case "issues":
        return "Issues"
      default:
        return ""
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500/10 text-green-500 hover:bg-green-500/20"
      case "offline":
        return "bg-red-500/10 text-red-500 hover:bg-red-500/20"
      case "issues":
        return "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20"
      default:
        return ""
    }
  }

  return (
    <Card className="mt-6 border bg-background/60 backdrop-blur supports-[backdrop-filter]:bg-background/30">
      <CardContent className="p-4">
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Server Status</h3>
            <Badge variant="outline" className="text-xs">
              Live
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-5">
            {loading
              ? Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <div key={i} className="flex flex-col items-center space-y-1 rounded-md border p-2">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-12" />
                    </div>
                  ))
              : regions.map((region) => (
                  <div key={region.id} className="flex flex-col items-center space-y-1 rounded-md border p-2">
                    <div className="text-xs font-medium">{region.name}</div>
                    <Badge
                      variant="outline"
                      className={`flex items-center gap-1 text-xs ${getStatusColor(region.status)}`}
                    >
                      {getStatusIcon(region.status)}
                      {getStatusText(region.status)}
                    </Badge>
                    <div className="text-xs text-muted-foreground">{region.latency}ms</div>
                  </div>
                ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

